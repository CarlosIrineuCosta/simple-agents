# LLM Orchestration System for Claude Code

> **Coordinate multiple LLMs within Claude Code to optimize costs and leverage specialized capabilities**

## What This Does

This system allows Claude Code to intelligently orchestrate tasks between multiple language models:

- **Claude (API)** - Complex reasoning, orchestration, context management
- **GLM (CLI/Subscription)** - Reasoning, thinking mode
- **Gemini (CLI/Subscription)** - General purpose, reasoning
- **Codex (CLI/Subscription)** - Code generation, refactoring, bug fixes

**Key Benefit:** Use CLI tools (subscription pricing) instead of expensive API calls when suitable, while Claude maintains intelligent orchestration.

## Quick Start

### 1. Install

```bash
cd /home/claude/llm-orchestration
chmod +x setup.sh
./setup.sh
```

### 2. Verify CLI Tools

The setup script checks for GLM, Gemini, and Codex. If not found:

```bash
# Check what's available
which glm glm-cli gemini codex

# If missing, install or add to PATH
export PATH="/path/to/glm:$PATH"
export PATH="/path/to/gemini:$PATH"
export PATH="/path/to/codex:$PATH"
```

### 3. Start Claude Code

```bash
cd /home/claude/llm-orchestration
claude
```

### 4. Use Orchestration Commands

```bash
# Intelligent routing (recommended)
/orchestrate Explain quantum computing

# Direct delegation to GLM
/delegate-glm Analyze the time complexity of sorting algorithms

# Direct delegation to Gemini
/delegate-gemini Explain the theory of relativity

# Direct delegation to Codex
/delegate-codex Create a function to validate email addresses
```

## How It Works

### Architecture

```
You → Claude Code → Intelligent Router
                         ↓
                    ┌────┴────┐
                    ↓         ↓
               GLM CLI    Codex CLI
               (bash)      (bash)
               Gemini CLI
               (bash)
```

### Decision Flow

1. **You give a task** to Claude Code
2. **Claude analyzes** and determines best agent:

   - Coding task? → Codex
   - Reasoning? → GLM or Gemini
   - Complex context? → Handle directly
3. **Executes via bash** tool using wrapper scripts
4. **Synthesizes results** into final answer

## Usage Examples

### Example 1: Intelligent Routing

```
User: /orchestrate Write a poetry analysis tool

Claude's Decision:
1. GLM analyzes poetry patterns
2. Codex generates the code
3. Claude integrates and tests

Result: Optimal cost, specialized expertise
```

### Example 2: Cost Optimization

```
User: /orchestrate Generate 50 product descriptions

Claude's Decision:
→ Routes to GLM (subscription, already paid)
→ Saves API tokens
→ Returns batch results

Result: $0 instead of expensive API calls
```

### Example 3: Multi-Agent Workflow

```
User: /orchestrate Build authentication system with security analysis

Claude's Workflow:
1. GLM: Security threat analysis
2. Codex: Code implementation
3. Claude: Integration, testing, documentation

Result: Each agent does what it does best
```

## Available Commands

### Core Commands

- `/orchestrate <task>` - **Recommended:** Intelligent routing to best agent
- `/delegate-glm <task>` - Send task directly to GLM CLI
- `/delegate-gemini <task>` - Send task directly to Gemini CLI
- `/delegate-codex <task>` - Send task directly to Codex CLI

### Direct Wrapper Usage

```bash
# GLM wrapper
bash /home/claude/llm-orchestration/glm_wrapper.sh [OPTIONS] "<prompt>"

Options:
  -m, --model MODEL      glm-4.5 (default) or glm-4.5-air
  -t, --thinking MODE    enabled (default) or disabled
  -o, --output FILE      Save to file

# Gemini wrapper
bash /home/claude/llm-orchestration/gemini_wrapper.sh [OPTIONS] "<prompt>"

Options:
  -o, --output FILE      Save to file

# Codex wrapper
bash /home/claude/llm-orchestration/codex_wrapper.sh [OPTIONS] "<task>"

Options:
  -f, --file FILE        Target file
  -c, --context DIR      Context directory
  -o, --output FILE      Save to file
```

## Cost Strategy

### When to Use Each Agent

| Task Type          | Best Agent | Cost         | Reasoning              |
| ------------------ | ---------- | ------------ | ---------------------- |
| Code generation    | Codex     | Subscription | Specialized for coding |
| General purpose    | Gemini     | Subscription | Strong reasoning       |
| Complex reasoning  | GLM        | Subscription | Thinking mode          |
| Multi-file changes | Claude     | API          | Needs context          |
| Orchestration      | Claude     | API          | Coordination role      |

**Rule of Thumb:** Delegate focused tasks to CLI tools, use Claude for orchestration.

## Configuration

### Environment Variables

```bash
# Add to ~/.bashrc or ~/.zshrc

# Wrapper scripts in PATH
export PATH="/home/claude/llm-orchestration:$PATH"

# GLM defaults
export GLM_MODEL="glm-4.5"
export GLM_THINKING="enabled"

# Timeout for all CLI calls
export TIMEOUT="180"
```

### Customizing Commands

Edit files in `.claude/commands/`:

- `orchestrate.md` - Routing logic
- `delegate-glm.md` - GLM delegation
- `delegate-gemini.md` - Gemini delegation
- `delegate-codex.md` - Codex delegation

## Documentation

- `CLAUDE.md` - Comprehensive system documentation (auto-loaded by Claude Code)
- `README.md` - This quick start guide
- Wrapper scripts have built-in `--help`

## Troubleshooting

### CLI Not Found

```bash
# Check installation
which glm
which gemini
which codex

# Test wrappers
bash glm_wrapper.sh --help
bash gemini_wrapper.sh --help
bash codex_wrapper.sh --help
```

### Timeout Issues

```bash
# Increase timeout
TIMEOUT=300 bash glm_wrapper.sh "complex task"

# Or use faster model
bash glm_wrapper.sh -m glm-4.5-air "task"
```

### Poor Results

1. Refine your prompt
2. Try different agent: `/orchestrate` vs direct delegation
3. Check wrapper output for errors
4. Combine multiple agents

## Best Practices

1. **Start with /orchestrate** - Let Claude choose
2. **Review outputs** - Validate quality before integration
3. **Chain agents** - GLM → Codex → Claude for complex tasks
4. **Monitor costs** - Prefer CLI delegation when suitable
5. **Iterate prompts** - Refine for better results

## Examples

### Simple Delegation

```
/delegate-glm Explain the differences between merge sort and quick sort
```

```
/delegate-gemini Explain the theory of relativity
```

### Coding Task

```
/delegate-codex Create a REST API endpoint for user registration
```

### Complex Workflow

```
/orchestrate Build a web scraper for news sites with sentiment analysis

Claude will:
1. Route analysis to GLM
2. Route coding to Codex (scraper implementation)
3. Integrate and test everything
```

## System Status

After setup, check status:

```bash
# Run setup again to see status
./setup.sh
```

Should show:

- ✓ Wrappers executable
- ✓ CLI tools available
- ✓ Commands configured
- ✓ Ready to use

## Contributing

To add new CLI tools:

1. Create wrapper script (follow existing pattern)
2. Add custom command in `.claude/commands/`
3. Update `CLAUDE.md` and routing logic
4. Test thoroughly

## License

MIT - Use freely, modify as needed

---

**Ready to orchestrate?** Start Claude Code and try `/orchestrate`!

For detailed documentation, see `CLAUDE.md`