#!/bin/bash
# Codex CLI Wrapper for Claude Code Orchestration
# This script wraps the Codex CLI to make it easy for Claude Code to delegate coding tasks

set -e  # Exit on error

# Configuration
TIMEOUT="${TIMEOUT:-180}"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Usage function
usage() {
    cat << EOF
Usage: $0 [OPTIONS] "<task_description>"

Options:
    -f, --file FILE         Target file for code changes
    -c, --context DIR       Context directory (default: current dir)
    -o, --output FILE       Save output to file
    -h, --help             Show this help message

Environment Variables:
    TIMEOUT                Command timeout in seconds (default: 180)

Examples:
    # Basic coding task
    $0 "Create a function to validate email addresses"

    # Modify specific file
    $0 -f utils.py "Add error handling to the parse function"

    # With context directory
    $0 -c ./src "Refactor the authentication module"

    # Save output
    $0 -o changes.diff "Fix the bug in login validation"
EOF
    exit 1
}

# Parse arguments
TARGET_FILE=""
CONTEXT_DIR="."
OUTPUT_FILE=""

while [[ $# -gt 0 ]]; do
    case $1 in
        -f|--file)
            TARGET_FILE="$2"
            shift 2
            ;;
        -c|--context)
            CONTEXT_DIR="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT_FILE="$2"
            shift 2
            ;;
        -h|--help)
            usage
            ;;
        *)
            TASK="$1"
            shift
            ;;
    esac
done

# Validate task description
if [ -z "$TASK" ]; then
    echo -e "${RED}Error: No task description provided${NC}" >&2
    usage
fi

# Log the request
echo -e "${BLUE}[Codex Wrapper] Processing coding task${NC}" >&2
echo -e "${BLUE}[Codex Wrapper] Task: ${TASK}${NC}" >&2
[ -n "$TARGET_FILE" ] && echo -e "${BLUE}[Codex Wrapper] Target file: ${TARGET_FILE}${NC}" >&2
echo -e "${BLUE}[Codex Wrapper] Context: ${CONTEXT_DIR}${NC}" >&2

# Check if Codex CLI is available
if ! command -v codex &> /dev/null; then
    echo -e "${RED}Error: Codex CLI not found in PATH${NC}" >&2
    echo -e "${RED}Please install Codex CLI or add it to your PATH${NC}" >&2
    exit 1
fi

# Build Codex command
# Note: Adjust this based on actual Codex CLI syntax
CODEX_CMD="codex"
CODEX_ARGS=()

if [ -n "$TARGET_FILE" ]; then
    CODEX_ARGS+=("--file" "$TARGET_FILE")
fi

CODEX_ARGS+=("--context" "$CONTEXT_DIR")
CODEX_ARGS+=("$TASK")

# Execute Codex with timeout
set +e  # Don't exit on error for timeout handling

if [ -n "$OUTPUT_FILE" ]; then
    # Save to file
    timeout "$TIMEOUT" $CODEX_CMD "${CODEX_ARGS[@]}" > "$OUTPUT_FILE" 2>&1
    EXIT_CODE=$?
    if [ $EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}[Codex Wrapper] Success! Output saved to: $OUTPUT_FILE${NC}" >&2
        cat "$OUTPUT_FILE"
    fi
else
    # Output to stdout
    OUTPUT=$(timeout "$TIMEOUT" $CODEX_CMD "${CODEX_ARGS[@]}" 2>&1)
    EXIT_CODE=$?
    if [ $EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}[Codex Wrapper] Success!${NC}" >&2
        echo "$OUTPUT"
    fi
fi

# Handle errors
if [ $EXIT_CODE -eq 124 ]; then
    echo -e "${RED}[Codex Wrapper] Error: Command timed out after ${TIMEOUT} seconds${NC}" >&2
    exit 124
elif [ $EXIT_CODE -ne 0 ]; then
    echo -e "${RED}[Codex Wrapper] Error: Codex CLI failed with exit code $EXIT_CODE${NC}" >&2
    exit $EXIT_CODE
fi

exit 0