# Expect-Based CLI Agent Orchestration

## What This Is

A working CLI orchestration system using `expect` to control interactive LLM tools without expensive APIs.

## Architecture

```
Claude Code (Orchestrator)
    ↓ bash tool
Bash Wrappers (glm_wrapper.sh, gemini_wrapper.sh, codex_wrapper.sh)
    ↓ calls
Expect Scripts (*.exp)
    ↓ controls
Interactive CLI Tools (Cline with GLM, Gemini CLI, Codex CLI)
```

## How It Works

1. **Claude Code** calls bash wrapper via bash tool
2. **Bash wrapper** calls corresponding `expect` script
3. **Expect script** spawns interactive CLI
4. **Expect** sends commands and captures output
5. **Expect** exits CLI properly
6. Output returned to Claude Code

## Files

```
wrappers/
├── cline_glm.exp          # Expect script for Cline/GLM
├── gemini.exp             # Expect script for Gemini
├── codex.exp              # Expect script for Codex
├── glm_wrapper.sh         # Bash wrapper for GLM
├── gemini_wrapper.sh      # Bash wrapper for Gemini
└── codex_wrapper.sh       # Bash wrapper for Codex
```

## Setup

### 1. Install Prerequisites

```bash
# Expect is already installed
which expect

# Verify Cline CLI
npm list -g @yaegaki/cline-cli

# If not installed:
npm install -g @yaegaki/cline-cli

# Configure Cline with your GLM API key
cline-cli init
# Edit ~/.cline_cli/cline_cli_settings.json
```

### 2. Make Scripts Executable

```bash
cd /path/to/simple-agents/agent-new/wrappers

chmod +x *.exp
chmod +x *.sh
```

### 3. Test Each Wrapper

```bash
# Test GLM via Cline
./glm_wrapper.sh "explain quantum computing in 2 sentences"

# Test Gemini  
./gemini_wrapper.sh "what is machine learning"

# Test Codex
./codex_wrapper.sh "create a Python function to sort a list"
```

## Testing Strategy

### Phase 1: Direct Expect Testing

```bash
# Test expect script directly
expect cline_glm.exp "hello world"
```

### Phase 2: Bash Wrapper Testing  

```bash
# Test bash wrapper
./glm_wrapper.sh "test prompt"
```

### Phase 3: Safe Environment Testing

```bash
# Create test directory
mkdir ~/agent-orchestration-test
cd ~/agent-orchestration-test

# Copy wrappers
cp /path/to/wrappers/* .

# Test with simple prompts
./glm_wrapper.sh "count to 5"
```

### Phase 4: Claude Code Integration

```bash
# Start Claude Code in project directory
cd /path/to/simple-agents/agent-new
claude

# Test via bash tool (in Claude Code):
# "Run: bash wrappers/glm_wrapper.sh 'test prompt'"
```

## Troubleshooting

### Expect not found
```bash
which expect
# Should show: /usr/bin/expect

# If not, reinstall:
sudo apt-get install --reinstall expect
```

### Cline CLI issues
```bash
# Check installation
npm list -g @yaegaki/cline-cli

# Test directly
npx -y @yaegaki/cline-cli task "hello"

# Check config
cat ~/.cline_cli/cline_cli_settings.json
```

### Timeouts
```bash
# Increase timeout in .exp files
# Change: set timeout 180
# To: set timeout 600
```

### No output captured
```bash
# Test expect script with debug mode
expect -d cline_glm.exp "test"

# Check for proper newline handling
# Ensure \r\n patterns match your CLI's output
```

## How Claude Code Uses It

When you use `/orchestrate` or `/delegate-glm`:

1. Claude Code determines which agent to use
2. Executes: `bash wrappers/glm_wrapper.sh "your prompt"`
3. Bash calls expect script
4. Expect controls CLI tool
5. Output captured and returned
6. Claude synthesizes response

## Cost Savings

- ✅ Uses subscription CLIs (already paid)
- ✅ No API token costs per request
- ✅ GLM 4.6 via Cline ($3/month)
- ✅ Gemini CLI (subscription)
- ✅ Codex (subscription)

## Next Steps

1. ✅ Verify `expect` installed
2. ✅ Test each expect script individually
3. ✅ Test bash wrappers
4. ⏹️ Integrate with Claude Code orchestration commands
5. ⏹️ Update `orchestrate.md` to use new wrappers
6. ⏹️ Test full workflow

## Debugging

### Enable Expect Debug Mode

```bash
# Run expect with debug flag
expect -d cline_glm.exp "test prompt"
```

### Capture Raw Output

```bash
# Modify .exp to show raw output
# Add before spawn:
log_user 1
exp_internal 1
```

### Test Pattern Matching

```bash
# Verify CLI output patterns
gemini "test" | cat -A
# Shows invisible characters like \r\n
```
