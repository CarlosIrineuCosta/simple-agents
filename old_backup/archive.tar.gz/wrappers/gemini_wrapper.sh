#!/bin/bash
# Gemini wrapper - called by Claude Code
# Usage: ./gemini_wrapper.sh "your prompt"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECT_SCRIPT="$SCRIPT_DIR/gemini.exp"

if [ -z "$1" ]; then
    echo "Error: No prompt provided"
    exit 1
fi

PROMPT="$1"

chmod +x "$EXPECT_SCRIPT" 2>/dev/null

expect "$EXPECT_SCRIPT" "$PROMPT"
EXIT_CODE=$?

exit $EXIT_CODE
