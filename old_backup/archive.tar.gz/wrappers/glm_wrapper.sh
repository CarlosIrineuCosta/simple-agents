#!/bin/bash
# GLM wrapper via Cline - called by Claude Code
# Usage: ./glm_wrapper.sh "your prompt"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECT_SCRIPT="$SCRIPT_DIR/cline_glm.exp"

if [ -z "$1" ]; then
    echo "Error: No prompt provided"
    exit 1
fi

PROMPT="$1"

# Make expect script executable if needed
chmod +x "$EXPECT_SCRIPT" 2>/dev/null

# Call expect script
expect "$EXPECT_SCRIPT" "$PROMPT"
EXIT_CODE=$?

exit $EXIT_CODE
