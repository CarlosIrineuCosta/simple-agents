#!/bin/bash
# Test script for expect-based CLI orchestration
# Usage: ./test_wrappers.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=================================="
echo "CLI Orchestration Test Suite"
echo "=================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# Test 1: Verify expect
echo -e "${BLUE}Test 1: Checking expect installation...${NC}"
if command -v expect &> /dev/null; then
    echo -e "${GREEN}✓ expect is installed: $(which expect)${NC}"
    expect -v
else
    echo -e "${RED}✗ expect not found${NC}"
    exit 1
fi
echo ""

# Test 2: Verify Cline CLI
echo -e "${BLUE}Test 2: Checking Cline CLI...${NC}"
if command -v npx &> /dev/null; then
    echo -e "${GREEN}✓ npx available${NC}"
    # Test if Cline CLI can be called
    if npx -y @yaegaki/cline-cli --help &> /dev/null; then
        echo -e "${GREEN}✓ Cline CLI accessible${NC}"
    else
        echo -e "${RED}✗ Cline CLI not accessible${NC}"
    fi
else
    echo -e "${RED}✗ npx not found (install Node.js)${NC}"
fi
echo ""

# Test 3: Verify Gemini CLI
echo -e "${BLUE}Test 3: Checking Gemini CLI...${NC}"
if command -v gemini &> /dev/null; then
    echo -e "${GREEN}✓ gemini found: $(which gemini)${NC}"
else
    echo -e "${RED}✗ gemini not found${NC}"
fi
echo ""

# Test 4: Verify Codex CLI
echo -e "${BLUE}Test 4: Checking Codex CLI...${NC}"
if command -v codex &> /dev/null; then
    echo -e "${GREEN}✓ codex found: $(which codex)${NC}"
else
    echo -e "${RED}✗ codex not found${NC}"
fi
echo ""

# Test 5: Check expect scripts exist
echo -e "${BLUE}Test 5: Checking expect scripts...${NC}"
for script in cline_glm.exp gemini.exp codex.exp; do
    if [ -f "$SCRIPT_DIR/$script" ]; then
        echo -e "${GREEN}✓ $script exists${NC}"
        chmod +x "$SCRIPT_DIR/$script"
    else
        echo -e "${RED}✗ $script missing${NC}"
    fi
done
echo ""

# Test 6: Check bash wrappers
echo -e "${BLUE}Test 6: Checking bash wrappers...${NC}"
for wrapper in glm_wrapper.sh gemini_wrapper.sh codex_wrapper.sh; do
    if [ -f "$SCRIPT_DIR/$wrapper" ]; then
        echo -e "${GREEN}✓ $wrapper exists${NC}"
        chmod +x "$SCRIPT_DIR/$wrapper"
    else
        echo -e "${RED}✗ $wrapper missing${NC}"
    fi
done
echo ""

# Test 7: Simple expect test
echo -e "${BLUE}Test 7: Testing expect with simple script...${NC}"
cat > /tmp/test_expect.exp << 'EOF'
#!/usr/bin/expect -f
puts "Expect is working!"
exit 0
EOF
chmod +x /tmp/test_expect.exp

if expect /tmp/test_expect.exp &> /dev/null; then
    echo -e "${GREEN}✓ Expect execution works${NC}"
else
    echo -e "${RED}✗ Expect execution failed${NC}"
fi
rm /tmp/test_expect.exp
echo ""

# Test 8: Interactive test (optional)
echo -e "${BLUE}Test 8: Ready for live tests${NC}"
echo ""
echo "Run these commands to test each wrapper:"
echo ""
echo "  ${BLUE}# Test GLM via Cline:${NC}"
echo "  ./glm_wrapper.sh \"say hello\""
echo ""
echo "  ${BLUE}# Test Gemini:${NC}"
echo "  ./gemini_wrapper.sh \"what is 2+2\""
echo ""
echo "  ${BLUE}# Test Codex:${NC}"
echo "  ./codex_wrapper.sh \"write hello world in Python\""
echo ""

echo "=================================="
echo "Test suite complete!"
echo "=================================="
