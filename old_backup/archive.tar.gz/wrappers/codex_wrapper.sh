#!/bin/bash
# Codex wrapper - called by Claude Code
# Usage: ./codex_wrapper.sh "your coding task"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECT_SCRIPT="$SCRIPT_DIR/codex.exp"

if [ -z "$1" ]; then
    echo "Error: No task provided"
    exit 1
fi

TASK="$1"

chmod +x "$EXPECT_SCRIPT" 2>/dev/null

expect "$EXPECT_SCRIPT" "$TASK"
EXIT_CODE=$?

exit $EXIT_CODE
