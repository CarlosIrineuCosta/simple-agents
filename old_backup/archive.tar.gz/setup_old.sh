#!/bin/bash
# Setup script for LLM Orchestration System in Claude Code

set -e

echo "Setting up LLM Orchestration System for Claude Code"
echo "=================================================="

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo ""
echo -e "${BLUE}Step 1: Making wrapper scripts executable${NC}"
chmod +x "$SCRIPT_DIR/glm_wrapper.sh"
chmod +x "$SCRIPT_DIR/gemini_wrapper.sh"
chmod +x "$SCRIPT_DIR/codex_wrapper.sh"
echo -e "${GREEN}✓ Wrapper scripts are now executable${NC}"

echo ""
echo -e "${BLUE}Step 2: Checking CLI tool availability${NC}"

# Check GLM
if command -v glm &> /dev/null; then
    echo -e "${GREEN}✓ GLM CLI found: $(which glm)${NC}"
    GLM_AVAILABLE=true
elif command -v glm-cli &> /dev/null; then
    echo -e "${GREEN}✓ GLM CLI found: $(which glm-cli)${NC}"
    GLM_AVAILABLE=true
else
    echo -e "${YELLOW}⚠ GLM CLI not found in PATH${NC}"
    echo -e "${YELLOW}  Please install GLM or add it to your PATH${NC}"
    GLM_AVAILABLE=false
fi

# Check Gemini
if command -v gemini &> /dev/null; then
    echo -e "${GREEN}✓ Gemini CLI found: $(which gemini)${NC}"
    GEMINI_AVAILABLE=true
else
    echo -e "${YELLOW}⚠ Gemini CLI not found in PATH${NC}"
    echo -e "${YELLOW}  Please install Gemini or add it to your PATH${NC}"
    GEMINI_AVAILABLE=false
fi

# Check Codex
if command -v codex &> /dev/null; then
    echo -e "${GREEN}✓ Codex CLI found: $(which codex)${NC}"
    CODEX_AVAILABLE=true
else
    echo -e "${YELLOW}⚠ Codex CLI not found in PATH${NC}"
    echo -e "${YELLOW}  Please install Codex or add it to your PATH${NC}"
    CODEX_AVAILABLE=false
fi

echo ""
echo -e "${BLUE}Step 3: Creating .claude/commands directory${NC}"
mkdir -p "$SCRIPT_DIR/.claude/commands"
echo -e "${GREEN}✓ Commands directory created${NC}"

echo ""
echo -e "${BLUE}Step 4: Verifying custom commands${NC}"
if [ -f "$SCRIPT_DIR/orchestrate.md" ]; then
    echo -e "${GREEN}✓ /orchestrate command available${NC}"
else
    echo -e "${RED}✗ /orchestrate command missing${NC}"
fi

if [ -f "$SCRIPT_DIR/delegate-glm.md" ]; then
    echo -e "${GREEN}✓ /delegate-glm command available${NC}"
else
    echo -e "${RED}✗ /delegate-glm command missing${NC}"
fi

if [ -f "$SCRIPT_DIR/delegate-gemini.md" ]; then
    echo -e "${GREEN}✓ /delegate-gemini command available${NC}"
else
    echo -e "${RED}✗ /delegate-gemini command missing${NC}"
fi

if [ -f "$SCRIPT_DIR/delegate_codex.md" ]; then
    echo -e "${GREEN}✓ /delegate-codex command available${NC}"
else
    echo -e "${RED}✗ /delegate-codex command missing${NC}"
fi

echo ""
echo -e "${BLUE}Step 5: Configuration Summary${NC}"
echo "=================================================="
echo -e "Installation Directory: ${GREEN}$SCRIPT_DIR${NC}"
echo -e "GLM Wrapper:           ${GREEN}$SCRIPT_DIR/glm_wrapper.sh${NC}"
echo -e "Gemini Wrapper:        ${GREEN}$SCRIPT_DIR/gemini_wrapper.sh${NC}"
echo -e "Codex Wrapper:         ${GREEN}$SCRIPT_DIR/codex_wrapper.sh${NC}"
echo -e "CLAUDE.md:             ${GREEN}$SCRIPT_DIR/claude.md${NC}"
echo ""
echo -e "Custom Commands:"
echo -e "  /orchestrate         ${GREEN}(Intelligent routing)${NC}"
echo -e "  /delegate-glm        ${GREEN}(GLM delegation)${NC}"
echo -e "  /delegate-gemini     ${GREEN}(Gemini delegation)${NC}"
echo -e "  /delegate-codex      ${GREEN}(Codex delegation)${NC}"

echo ""
echo -e "${BLUE}Step 6: Environment Configuration${NC}"
echo "=================================================="
cat << 'EOF'

Add these to your ~/.bashrc or ~/.zshrc for easier access:

# LLM Orchestration Wrappers
export PATH="/home/claude/llm-orchestration:$PATH"

# GLM Configuration (optional)
export GLM_MODEL="glm-4.5"           # or glm-4.5-air
export GLM_THINKING="enabled"        # or disabled

# Codex Configuration (optional)
export TIMEOUT="180"                  # timeout in seconds

Then reload your shell:
    source ~/.bashrc   # or source ~/.zshrc

EOF

echo ""
echo -e "${BLUE}Step 7: Testing${NC}"
echo "=================================================="

# Create test directory
mkdir -p "$SCRIPT_DIR/tests"

# Test wrapper scripts with dry run
echo "Testing wrapper scripts..."

if [ "$GLM_AVAILABLE" = true ]; then
    echo -e "${BLUE}Testing GLM wrapper...${NC}"
    bash "$SCRIPT_DIR/glm_wrapper.sh" --help > /dev/null 2>&1 && \
        echo -e "${GREEN}✓ GLM wrapper help works${NC}" || \
        echo -e "${RED}✗ GLM wrapper failed${NC}"
fi

if [ "$GEMINI_AVAILABLE" = true ]; then
    echo -e "${BLUE}Testing Gemini wrapper...${NC}"
    bash "$SCRIPT_DIR/gemini_wrapper.sh" --help > /dev/null 2>&1 && \
        echo -e "${GREEN}✓ Gemini wrapper help works${NC}" || \
        echo -e "${RED}✗ Gemini wrapper failed${NC}"
fi

if [ "$CODEX_AVAILABLE" = true ]; then
    echo -e "${BLUE}Testing Codex wrapper...${NC}"
    bash "$SCRIPT_DIR/codex_wrapper.sh" --help > /dev/null 2>&1 && \
        echo -e "${GREEN}✓ Codex wrapper help works${NC}" || \
        echo -e "${RED}✗ Codex wrapper failed${NC}"
fi

echo ""
echo -e "${GREEN}🎉 Setup Complete!${NC}"
echo "=================================================="
echo ""
echo -e "${BLUE}Next Steps:${NC}"
echo ""
echo "1. Open Claude Code in this directory:"
echo -e "   ${YELLOW}cd $SCRIPT_DIR${NC}"
echo -e "   ${YELLOW}claude${NC}"
echo ""
echo "2. Try the orchestration system:"
echo -e "   ${YELLOW}/orchestrate Explain quantum computing${NC}"
echo ""
echo "3. Or delegate directly:"
echo -e "   ${YELLOW}/delegate-glm Analyze the complexity of sorting algorithms${NC}"
echo -e "   ${YELLOW}/delegate-codex Create a user authentication function${NC}"
echo ""
echo "4. Read claude.md for comprehensive usage guide"
echo ""
echo -e "${BLUE}Documentation:${NC}"
echo -e "  View: ${YELLOW}cat claude.md${NC}"
echo -e "  Edit: ${YELLOW}vim claude.md${NC}"  # or nano

echo ""

# Final status
echo -e "${BLUE}System Status:${NC}"
[ "$GLM_AVAILABLE" = true ] && echo -e "  GLM CLI:    ${GREEN}Ready${NC}" || echo -e "  GLM CLI:    ${YELLOW}Not configured${NC}"
[ "$GEMINI_AVAILABLE" = true ] && echo -e "  Gemini CLI: ${GREEN}Ready${NC}" || echo -e "  Gemini CLI: ${YELLOW}Not configured${NC}"
[ "$CODEX_AVAILABLE" = true ] && echo -e "  Codex CLI:  ${GREEN}Ready${NC}" || echo -e "  Codex CLI:  ${YELLOW}Not configured${NC}"
echo -e "  Wrappers:   ${GREEN}Ready${NC}"
echo -e "  Commands:   ${GREEN}Ready${NC}"
echo ""

if [ "$GLM_AVAILABLE" = false ] || [ "$CODEX_AVAILABLE" = false ] || [ "$GEMINI_AVAILABLE" = false ]; then
    echo -e "${YELLOW}⚠ Note: Some CLI tools are not configured.${NC}"
    echo -e "${YELLOW}  The system will still work with available tools.${NC}"
    echo ""
fi

echo "Happy orchestrating! 🎵"