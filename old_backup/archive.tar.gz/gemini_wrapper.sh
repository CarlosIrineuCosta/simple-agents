#!/bin/bash
# Gemini CLI Wrapper for Claude Code Orchestration
# This script wraps the Gemini CLI to make it easy for Claude Code to delegate tasks

set -e  # Exit on error

# Configuration
TIMEOUT="${TIMEOUT:-180}"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Usage function
usage() {
    cat << EOF
Usage: $0 [OPTIONS] "<prompt>"

Options:
    -o, --output FILE       Save output to file
    -h, --help             Show this help message

Environment Variables:
    TIMEOUT                Command timeout in seconds (default: 180)

Examples:
    # Basic usage
    $0 "Explain the theory of relativity"

    # Save output
    $0 -o result.txt "Summarize the latest AI research"
EOF
    exit 1
}

# Parse arguments
OUTPUT_FILE=""
while [[ $# -gt 0 ]]; do
    case $1 in
        -o|--output)
            OUTPUT_FILE="$2"
            shift 2
            ;;
        -h|--help)
            usage
            ;;
        *)
            PROMPT="$1"
            shift
            ;;
    esac
done

# Validate prompt
if [ -z "$PROMPT" ]; then
    echo -e "${RED}Error: No prompt provided${NC}" >&2
    usage
fi

# Log the request
echo -e "${BLUE}[Gemini Wrapper] Sending to Gemini CLI${NC}" >&2
echo -e "${BLUE}[Gemini Wrapper] Prompt: ${PROMPT}${NC}" >&2

# Check if Gemini CLI is available
if ! command -v gemini &> /dev/null; then
    echo -e "${RED}Error: Gemini CLI not found in PATH${NC}" >&2
    echo -e "${RED}Please install the Gemini CLI or add it to your PATH${NC}" >&2
    exit 1
fi

# Execute Gemini with timeout
set +e  # Don't exit on error for timeout handling
if [ -n "$OUTPUT_FILE" ]; then
    # Save to file
    timeout "$TIMEOUT" gemini "$PROMPT" > "$OUTPUT_FILE" 2>&1
    EXIT_CODE=$?
    if [ $EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}[Gemini Wrapper] Success! Output saved to: $OUTPUT_FILE${NC}" >&2
        cat "$OUTPUT_FILE"
    fi
else
    # Output to stdout
    OUTPUT=$(timeout "$TIMEOUT" gemini "$PROMPT" 2>&1)
    EXIT_CODE=$?
    if [ $EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}[Gemini Wrapper] Success!${NC}" >&2
        echo "$OUTPUT"
    fi
fi

# Handle errors
if [ $EXIT_CODE -eq 124 ]; then
    echo -e "${RED}[Gemini Wrapper] Error: Command timed out after ${TIMEOUT} seconds${NC}" >&2
    exit 124
elif [ $EXIT_CODE -ne 0 ]; then
    echo -e "${RED}[Gemini Wrapper] Error: Gemini CLI failed with exit code $EXIT_CODE${NC}" >&2
    exit $EXIT_CODE
fi

exit 0
