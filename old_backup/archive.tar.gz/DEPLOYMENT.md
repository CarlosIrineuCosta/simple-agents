# LLM Orchestration System - Deployment Guide

## System Created Successfully!

Your multi-LLM orchestration system for Claude Code is ready. Here's everything you need to know.

## What Was Built

### Core Components

1. **Wrapper Scripts** (Bash)

   - `glm_wrapper.sh` - Calls GLM CLI with proper formatting
   - `codecs_wrapper.sh` - Calls Codecs CLI with proper formatting
1. **Custom Commands** (Claude Code slash commands)

   - `/orchestrate` - Intelligent routing to best LLM
   - `/delegate-glm` - Send tasks to GLM
   - `/delegate-codecs` - Send tasks to Codecs
1. **Configuration Files**

   - `CLAUDE.md` - Auto-loaded by Claude Code
   - `README.md` - Quick start guide
   - `setup.sh` - One-command setup

### File Structure

```
/home/claude/llm-orchestration/
├── CLAUDE.md                    # Main config (auto-loaded)
├── README.md                    # Quick start
├── setup.sh                     # Setup script
├── glm_wrapper.sh               # GLM CLI wrapper
├── codecs_wrapper.sh            # Codecs CLI wrapper
└── .claude/
    └── commands/
        ├── orchestrate.md       # /orchestrate command
        ├── delegate-glm.md      # /delegate-glm command
        └── delegate-codecs.md   # /delegate-codecs command
```

## Next Steps

### Step 1: Verify CLI Tools

Before using the system, ensure GLM and Codecs CLIs are installed:

```bash
# Check GLM
which glm
# or
which glm-cli

# Check Codecs
which codecs
```

**If not found:** Install them or add to PATH.

### Step 2: Run Setup

```bash
cd /home/claude/llm-orchestration
./setup.sh
```

This will:

- Make all scripts executable
- Verify CLI tools
- Check command configuration
- Show system status

### Step 3: Configure GLM CLI

You mentioned you installed GLM and switched to their client. You need to:

```bash
# Find your GLM installation
which glm

# Test it works
glm --help
# or
glm-cli --help
```

**Important:** Update the wrapper script if GLM uses different syntax:

1. Test GLM manually to learn its CLI syntax
2. Edit `/home/claude/llm-orchestration/glm_wrapper.sh`
3. Update the command building section (lines ~50-80)

### Step 4: Configure Codecs CLI

Same process for Codecs:

```bash
# Find Codecs
which codecs

# Test it
codecs --help
```

Update `/home/claude/llm-orchestration/codecs_wrapper.sh` if needed.

### Step 5: Start Claude Code

```bash
cd /home/claude/llm-orchestration
claude
```

Claude Code will automatically load `CLAUDE.md` and make slash commands available.

## Using the System

### Basic Usage

In Claude Code, type:

```
/orchestrate <your task>
```

Claude will:

1. Analyze the task
2. Choose the best LLM (Claude/GLM/Codecs)
3. Execute via bash if delegating
4. Synthesize the results

### Direct Delegation

```
/delegate-glm Explain sorting algorithm complexity

/delegate-codecs Create a user authentication function
```

### Advanced: Manual Bash Calls

If you want full control, call wrappers directly:

```bash
bash /home/claude/llm-orchestration/glm_wrapper.sh "Your prompt"

bash /home/claude/llm-orchestration/codecs_wrapper.sh "Your task"
```

## Customization

### Adjust GLM Defaults

Edit `glm_wrapper.sh`:

- Change default model (line ~8)
- Change thinking mode (line ~9)
- Adjust timeout (line ~10)

Or set environment variables:

```bash
export GLM_MODEL="glm-4.5-air"
export GLM_THINKING="disabled"
export TIMEOUT="300"
```

### Modify Routing Logic

Edit `.claude/commands/orchestrate.md` to change:

- When to use each agent
- Cost optimization rules
- Multi-agent workflows

### Add New CLI Tools

1. Create wrapper script (copy existing pattern)
2. Add custom command in `.claude/commands/`
3. Update orchestrate logic
4. Test thoroughly

## How It Actually Works

### When You Type `/orchestrate <task>`:

1. **Command File Loaded**: `.claude/commands/orchestrate.md`
2. **Claude Analyzes**: Determines best agent
3. **Decision Made**:

   - Code task? → `/delegate-codecs`
   - Reasoning? → `/delegate-glm`
   - Complex? → Handle directly
4. **Bash Execution**: Wrapper scripts called via bash tool
5. **Result Processing**: Claude synthesizes outputs
6. **Final Answer**: Delivered to you

### Cost Savings

**Before:**

- All tasks use Claude API ($$$)
- Token costs add up quickly

**After:**

- Focused tasks → CLI tools (subscription, $0)
- Complex orchestration → Claude API (moderate)
- Result: 50-80% cost reduction

## Troubleshooting

### Problem: CLI Not Found

**Solution:**

```bash
# Option 1: Install CLI
npm install -g glm-cli  # or whatever install method

# Option 2: Add to PATH
export PATH="/path/to/cli:$PATH"

# Option 3: Use full path in wrapper
# Edit wrapper script, replace 'glm' with '/full/path/to/glm'
```

### Problem: Wrapper Fails

**Debug:**

```bash
# Test wrapper directly
bash -x /home/claude/llm-orchestration/glm_wrapper.sh "test"

# Check permissions
ls -la /home/claude/llm-orchestration/*.sh

# Make executable if needed
chmod +x /home/claude/llm-orchestration/*.sh
```

### Problem: Commands Not Available

**Solution:**

```bash
# In Claude Code, check:
/commands

# Should show:
#   /orchestrate
#   /delegate-glm
#   /delegate-codecs

# If missing, check location:
ls -la /home/claude/llm-orchestration/.claude/commands/
```

### Problem: Syntax Errors in CLI Calls

**Solution:**

1. Test CLI manually: `glm --help`
2. Note actual syntax
3. Edit wrapper script to match
4. Test wrapper: `bash glm_wrapper.sh "test"`

## Performance Tips

### For GLM:

- Use `glm-4.5-air` for speed
- Use `glm-4.5` for complex reasoning
- Enable thinking mode only when needed
- Set reasonable timeouts

### For Codecs:

- Be specific in task descriptions
- Provide file context when relevant
- Use for focused coding tasks
- Test generated code before integration

### For Claude (You):

- Handle complex multi-file operations
- Maintain project context
- Orchestrate workflows
- Synthesize results from other agents

## Learning Path

### Week 1: Basic Usage

- Use `/orchestrate` for everything
- Observe routing decisions
- Learn agent strengths

### Week 2: Direct Delegation

- Use `/delegate-glm` and `/delegate-codecs`
- Compare with `/orchestrate` results
- Understand cost differences

### Week 3: Advanced Workflows

- Chain multiple agents
- Customize routing logic
- Optimize for your use cases

### Week 4: Mastery

- Add new CLI tools
- Build custom workflows
- Fine-tune performance

## 📚 Additional Resources

- **CLAUDE.md**: Comprehensive documentation
- **README.md**: Quick reference
- **Wrapper scripts**: `--help` flags
- **Custom commands**: Edit `.claude/commands/*.md`

## ✅ Verification Checklist

Before first use:

- [ ] Run `./setup.sh` successfully
- [ ] GLM CLI is accessible
- [ ] Codecs CLI is accessible
- [ ] Wrappers are executable
- [ ] Commands show in Claude Code
- [ ] Test simple orchestration

## 🚦 Quick Test

In Claude Code, try:

```
/orchestrate Tell me a joke about programming in Chinese
```

Expected:

1. Claude recognizes "Chinese" → routes to GLM
2. Calls GLM via bash wrapper
3. Gets response
4. Returns synthesized answer

## 🎊 Success Indicators

You'll know it's working when:

- Claude chooses appropriate agents
- CLI calls execute successfully
- Results are synthesized well
- Costs are lower than before
- Workflow feels smooth

## 📞 Support

If you encounter issues:

1. Check wrapper script syntax matches your CLI
2. Verify PATH configuration
3. Test wrappers manually first
4. Read error messages in bash output
5. Adjust wrapper scripts as needed

## 🔮 Future Enhancements

Consider adding:

- More CLI tool wrappers
- Result caching system
- Performance metrics
- Cost tracking dashboard
- Automated A/B testing
- Quality scoring

---

## 🎬 Ready to Deploy!

**Your next command:**

```bash
cd /home/claude/llm-orchestration
./setup.sh
```

Then start Claude Code and try `/orchestrate`!

**Remember:** This system works INSIDE Claude Code, leveraging its bash tool capabilities to orchestrate multiple LLMs while maintaining intelligent control.

Happy orchestrating! 🎵
