---
name: delegate-glm
description: Delegate a task to GLM CLI (uses subscription, not API)
---

You are Claude Code orchestrating multiple LLM agents. A user wants to delegate a task to GLM (via CLI).

## Task to Delegate

$ARGUMENTS

## Your Orchestration Process

1. **Analyze the task** and determine if GLM is suitable:

   - GLM excels at: reasoning, mathematical thinking
   - GLM has thinking mode for complex analysis
   - Consider if this task benefits from GLM's strengths
1. **Execute the delegation**:

   - Use the GLM wrapper script: `/home/claude/llm-orchestration/glm_wrapper.sh`
   - Choose appropriate model:
       - `glm-4.5` for complex reasoning
       - `glm-4.5-air` for faster responses
   - Enable thinking mode for complex tasks
1. **Example bash commands**:

   ```bash
   # For complex reasoning
   bash /home/claude/llm-orchestration/glm_wrapper.sh -m glm-4.5 -t enabled "Your refined prompt here"

   # For quick responses
   bash /home/claude/llm-orchestration/glm_wrapper.sh -m glm-4.5-air -t disabled "Your refined prompt here"
   ```
1. **Process the response**:

   - Review GLM's output
   - Synthesize it into a coherent answer
   - If the output is inadequate, try again with a refined prompt
   - You can combine GLM's output with your own analysis
1. **Token efficiency**:

   - Using GLM CLI costs nothing (subscription already paid)
   - This saves your Claude API tokens for orchestration
   - Delegate when it makes sense, but stay in control

## Important Notes

- The wrapper script handles timeouts and errors
- GLM output will appear in bash tool results
- You orchestrate the overall workflow
- Synthesize the final answer from all sources

Now execute the delegation and provide the synthesized result to the user.