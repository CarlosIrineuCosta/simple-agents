# 🚀 Deployment Checklist

## Pre-Deployment

### 1. Verify GLM CLI Installation

- [ ] GLM CLI is installed
- [ ] Test: `glm --help` OR `glm-cli --help`
- [ ] Note the exact command syntax
- [ ] Verify it works: Try a simple prompt
- [ ] Record any special flags needed

**If GLM CLI uses different syntax:**

- [ ] Edit `/home/claude/llm-orchestration/glm_wrapper.sh`
- [ ] Update command building section (around line 70)
- [ ] Test wrapper: `bash glm_wrapper.sh "test prompt"`

### 2. Verify Codecs CLI Installation

- [ ] Codecs CLI is installed
- [ ] Test: `codecs --help`
- [ ] Note the exact command syntax
- [ ] Verify it works: Try a simple task
- [ ] Record any special flags needed

**If Codecs CLI uses different syntax:**

- [ ] Edit `/home/claude/llm-orchestration/codecs_wrapper.sh`
- [ ] Update command building section
- [ ] Test wrapper: `bash codecs_wrapper.sh "test task"`

### 3. Environment Configuration

- [ ] Add wrappers to PATH (optional but recommended):

  ```bash
  export PATH="/home/claude/llm-orchestration:$PATH"
  ```
- [ ] Set GLM defaults (optional):

  ```bash
  export GLM_MODEL="glm-4.5"
  export GLM_THINKING="enabled"
  ```
- [ ] Set timeout (optional):

  ```bash
  export TIMEOUT="180"
  ```
- [ ] Add to `~/.bashrc` or `~/.zshrc` to persist

## Deployment

### 4. Run Setup Script

```bash
cd /home/claude/llm-orchestration
./setup.sh
```

Verify output shows:

- [ ] ✓ Wrapper scripts are executable
- [ ] ✓ GLM CLI found (if installed)
- [ ] ✓ Codecs CLI found (if installed)
- [ ] ✓ Commands directory created
- [ ] ✓ All custom commands available
- [ ] ✓ System status: Ready

### 5. Verify File Structure

```bash
tree /home/claude/llm-orchestration
```

Should show:

- [ ] `CLAUDE.md` (main config)
- [ ] `README.md` (quick start)
- [ ] `DEPLOYMENT.md` (this guide)
- [ ] `ARCHITECTURE.md` (diagrams)
- [ ] `setup.sh` (setup script)
- [ ] `glm_wrapper.sh` (GLM wrapper)
- [ ] `codecs_wrapper.sh` (Codecs wrapper)
- [ ] `.claude/commands/orchestrate.md`
- [ ] `.claude/commands/delegate-glm.md`
- [ ] `.claude/commands/delegate-codecs.md`

### 6. Test Wrappers Independently

**Test GLM Wrapper:**

```bash
cd /home/claude/llm-orchestration
bash glm_wrapper.sh "What is 2+2?"
```

- [ ] No errors
- [ ] Returns valid response
- [ ] Exit code is 0

**Test Codecs Wrapper:**

```bash
bash codecs_wrapper.sh "Create a hello world function"
```

- [ ] No errors
- [ ] Returns code
- [ ] Exit code is 0

**If tests fail:**

- [ ] Check CLI installation
- [ ] Verify wrapper syntax matches CLI
- [ ] Check PATH configuration
- [ ] Review error messages

## First Use in Claude Code

### 7. Start Claude Code

```bash
cd /home/claude/llm-orchestration
claude
```

### 8. Verify Commands Available

In Claude Code, type:

```
/
```

Then press Tab to see autocomplete.

Should see:

- [ ] `/orchestrate`
- [ ] `/delegate-glm`
- [ ] `/delegate-codecs`

**If commands missing:**

- [ ] Check `.claude/commands/` directory exists
- [ ] Verify markdown files are present
- [ ] Restart Claude Code
- [ ] Check file permissions

### 9. Test Basic Orchestration

```
/orchestrate Tell me a programming joke
```

Expected behavior:

- [ ] Claude analyzes the task
- [ ] Makes a routing decision
- [ ] Executes chosen agent
- [ ] Returns synthesized answer

### 10. Test GLM Delegation

```
/delegate-glm Explain the Fibonacci sequence
```

Expected behavior:

- [ ] Claude calls glm_wrapper.sh via bash
- [ ] GLM processes request
- [ ] Returns response
- [ ] Claude synthesizes result

### 11. Test Codecs Delegation

```
/delegate-codecs Create a function to calculate factorial
```

Expected behavior:

- [ ] Claude calls codecs_wrapper.sh via bash
- [ ] Codecs generates code
- [ ] Returns code
- [ ] Claude reviews and presents

### 12. Test Multi-Agent Workflow

```
/orchestrate Create a Chinese greeting function with detailed documentation
```

Expected behavior:

- [ ] Claude identifies need for multiple agents
- [ ] Routes to GLM for Chinese content
- [ ] Routes to Codecs for code
- [ ] Synthesizes complete solution

## Validation

### 13. Performance Check

- [ ] Commands respond quickly (<5 seconds)
- [ ] No timeout errors
- [ ] Bash execution works smoothly
- [ ] Results are high quality

### 14. Cost Verification

In Claude Code, check token usage:

```
/usage
```

- [ ] Orchestration uses minimal Claude tokens
- [ ] Delegated tasks show as bash execution
- [ ] Overall cost is lower than all-Claude approach

### 15. Error Handling

Intentionally cause errors to test:

**Test missing CLI:**

- [ ] Temporarily rename GLM CLI
- [ ] Try `/delegate-glm`
- [ ] Should show clear error message
- [ ] Should suggest fallback

**Test timeout:**

- [ ] Set very short timeout: `TIMEOUT=1`
- [ ] Try complex task
- [ ] Should timeout gracefully
- [ ] Should return error code 124

**Test invalid prompt:**

- [ ] Use empty prompt
- [ ] Should show usage help
- [ ] No crashes

## Optimization

### 16. Fine-Tune Performance

Based on results:

- [ ] Adjust timeouts if needed
- [ ] Set optimal default models
- [ ] Configure thinking mode preferences
- [ ] Update routing logic if needed

### 17. Customize for Your Workflow

- [ ] Edit `orchestrate.md` routing rules
- [ ] Add project-specific commands
- [ ] Create shortcuts for common tasks
- [ ] Document team conventions

## Documentation

### 18. Team Onboarding

If sharing with team:

- [ ] Share setup instructions
- [ ] Document CLI installation steps
- [ ] Provide usage examples
- [ ] Create troubleshooting guide

### 19. Personal Reference

- [ ] Bookmark key files
- [ ] Note common commands
- [ ] Document custom configurations
- [ ] Track cost savings

## Ongoing Maintenance

### 20. Regular Checks

Weekly:

- [ ] Verify CLI tools still work
- [ ] Check for wrapper updates needed
- [ ] Review cost vs. performance
- [ ] Update routing logic

Monthly:

- [ ] Review and optimize prompts
- [ ] Update documentation
- [ ] Add new capabilities
- [ ] Share learnings

## Success Criteria

### System is Working When:

- [ ] ✅ Can route tasks intelligently
- [ ] ✅ CLI delegations execute successfully
- [ ] ✅ Multi-agent workflows complete
- [ ] ✅ Cost is 50-80% lower than before
- [ ] ✅ Quality remains high
- [ ] ✅ No manual intervention needed
- [ ] ✅ Error handling is graceful
- [ ] ✅ Documentation is clear

## Troubleshooting Quick Reference

### Common Issues

**"Command not found"**

→ Check: `which glm` and `which codecs`

→ Fix: Install CLIs or add to PATH

**"Permission denied"**

→ Check: `ls -la *.sh`

→ Fix: `chmod +x *.sh`

**"Timeout errors"**

→ Check: Current timeout value

→ Fix: `export TIMEOUT=300`

**"Commands not showing"**

→ Check: `.claude/commands/*.md` exist

→ Fix: Restart Claude Code

**"Wrong CLI syntax"**

→ Check: Test CLI manually

→ Fix: Edit wrapper scripts to match

**"Poor results"**

→ Check: Prompt quality

→ Fix: Refine prompts, try different agent

## Next Steps After Deployment

### Immediate (Day 1):

- [ ] Test with real tasks
- [ ] Monitor performance
- [ ] Note any issues
- [ ] Adjust as needed

### Short-term (Week 1):

- [ ] Build confidence with system
- [ ] Learn routing patterns
- [ ] Optimize configurations
- [ ] Document workflows

### Long-term (Month 1):

- [ ] Add new capabilities
- [ ] Share with team (if applicable)
- [ ] Measure ROI
- [ ] Expand use cases

## Support Resources

**Documentation:**

- `README.md` - Quick start
- `CLAUDE.md` - Comprehensive guide
- `DEPLOYMENT.md` - Deployment guide
- `ARCHITECTURE.md` - System design

**Scripts:**

- `setup.sh --help` - Setup assistance
- `glm_wrapper.sh --help` - GLM usage
- `codecs_wrapper.sh --help` - Codecs usage

**Community:**

- Claude Code documentation
- Anthropic forums
- Your team Slack/Discord

---

## 🎉 You're Ready!

Once all checkboxes are complete, your LLM orchestration system is fully deployed and operational.

**Start using it:**

```bash
cd /home/claude/llm-orchestration
claude
/orchestrate <your task>
```

**Happy orchestrating! 🎵**
