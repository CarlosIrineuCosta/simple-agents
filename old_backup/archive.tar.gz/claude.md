# LLM Orchestration System for Claude Code

This project implements an intelligent multi-LLM orchestration system where Claude Code coordinates tasks between multiple language models to optimize cost and performance.

## Architecture

```
Claude Code (Orchestrator - Sonnet 4.5)
    ↓
    ├─→ GLM CLI (reasoning, thinking mode)
    ├─→ Gemini CLI (general purpose, reasoning)
    ├─→ Codex CLI (code generation, refactoring)
    └─→ Claude API (complex context, coordination)
```

## Available Commands

### Core Orchestration Commands

- `/orchestrate <task>` - Intelligently route task to best LLM
- `/delegate-glm <task>` - Delegate to GLM CLI
- `/delegate-gemini <task>` - Delegate to Gemini CLI
- `/delegate-codex <task>` - Delegate to Codex CLI

### How It Works

1. **Cost-Aware Routing**: Prefers CLI tools (subscription) over API when suitable
2. **Multi-Agent Workflows**: Can chain multiple LLMs for complex tasks
3. **Context Management**: Claude maintains orchestration while delegating execution

## Wrapper Scripts

Located in `/home/claude/llm-orchestration/`:

### GLM Wrapper (`glm_wrapper.sh`)

```bash
# Basic usage
bash glm_wrapper.sh "Your prompt"

# With specific model
bash glm_wrapper.sh -m glm-4.5-air "Quick task"

# Enable thinking mode
bash glm_wrapper.sh -t enabled "Complex reasoning task"

# Save output
bash glm_wrapper.sh -o result.txt "Analysis task"
```

### Gemini Wrapper (`gemini_wrapper.sh`)

```bash
# Basic usage
bash gemini_wrapper.sh "Your prompt"

# Save output
bash gemini_wrapper.sh -o result.txt "Analysis task"
```

### Codex Wrapper (`codex_wrapper.sh`)

```bash
# Basic usage
bash codex_wrapper.sh "Create a function"

# Target specific file
bash codex_wrapper.sh -f utils.py "Add error handling"

# With context
bash codex_wrapper.sh -c ./src "Refactor module"
```

## Usage Patterns

### Pattern 1: Simple Delegation

```
User: "Explain quantum computing"
Claude: /orchestrate Explain quantum computing
→ Routes to Gemini (general purpose reasoning)
```

### Pattern 2: Multi-Agent Workflow

```
User: "Build a user authentication system"
Claude: /orchestrate Build a user authentication system
→ GLM: Analyze security requirements
→ Codex: Generate code implementation
→ Claude: Integrate and test
```

### Pattern 3: Cost Optimization

```
User: "Generate 100 product descriptions"
Claude: /delegate-glm <batch task>
→ Uses subscription instead of expensive API
```

## Cost Optimization Strategy

### When to Use Each Agent

**Claude (API - moderate cost):**

- Complex multi-file operations
- Architectural decisions
- Context-heavy tasks
- Orchestration and coordination

**GLM (CLI - subscription only):**

- Reasoning and analysis tasks
- Mathematical/logical problems
- Thinking mode for complex analysis

**Gemini (CLI - subscription only):**

- General purpose tasks
- Strong reasoning and instruction-following

**Codex (CLI - subscription only):**

- Code generation
- Refactoring tasks
- Bug fixes
- Focused code modifications

**Cost Rule:** Delegate to CLI when possible, use Claude API for orchestration

## Environment Setup

### Required CLI Tools

1. **GLM CLI**: Must be in PATH

   - Check: `which glm` or `which glm-cli`
   - Configure: Set GLM_MODEL, GLM_THINKING env vars
1. **Gemini CLI**: Must be in PATH

   - Check: `which gemini`
1. **Codex CLI**: Must be in PATH

   - Check: `which codex`

### Make Wrappers Executable

```bash
chmod +x /home/claude/llm-orchestration/glm_wrapper.sh
chmod +x /home/claude/llm-orchestration/gemini_wrapper.sh
chmod +x /home/claude/llm-orchestration/codex_wrapper.sh
```

### Optional: Add to PATH

```bash
export PATH="/home/claude/llm-orchestration:$PATH"
```

## Bash Command Execution

When using wrappers in bash:

- Always use full paths initially
- Wrappers handle errors and timeouts
- Output is captured and returned
- Errors are logged to stderr

## Development Workflow

### For New Features

1. Analyze with `/orchestrate`
2. Let system route to optimal agent
3. Review and integrate results

### For Code Tasks

1. Use `/delegate-codex` for focused tasks
2. Use Claude directly for multi-file changes
3. Combine both for complex features

### For Analysis Tasks

1. Use `/delegate-glm` for reasoning
2. Use Claude for synthesis
3. Combine outputs for comprehensive answers

## Debugging

### Check CLI Availability

```bash
which glm
which glm-cli
which gemini
which codex
```

### Test Wrappers

```bash
bash /home/claude/llm-orchestration/glm_wrapper.sh -h
bash /home/claude/llm-orchestration/gemini_wrapper.sh -h
bash /home/claude/llm-orchestration/codex_wrapper.sh -h
```

### View Command Output

- Wrappers log to stderr (visible in Claude)
- Actual responses on stdout
- Error codes indicate issues

## Security Notes

- Wrappers validate inputs
- Timeouts prevent hanging
- CLI tools run in user context
- No system-level access granted

## Best Practices

1. **Start with /orchestrate** - Let Claude decide routing
2. **Review delegated outputs** - Validate quality
3. **Chain agents for complexity** - GLM → Codex → Claude
4. **Monitor costs** - Prefer CLI delegation
5. **Use thinking mode sparingly** - GLM thinking adds latency

## Troubleshooting

### "CLI not found" Error

- Check PATH configuration
- Verify CLI installation
- Use full path in wrapper scripts

### Timeout Issues

- Increase timeout: `TIMEOUT=300 bash wrapper.sh`
- Simplify prompts
- Use faster models (glm-4.5-air)

### Poor Results

- Refine prompts
- Try different agents
- Combine multiple agents
- Use Claude's context understanding

## Advanced: Parallel Execution

For independent tasks, run in background:

```bash
bash glm_wrapper.sh "Task 1" > result1.txt &
bash codex_wrapper.sh "Task 2" > result2.txt &
wait
# Combine results
```

## Future Enhancements

- [ ] Add more CLI tool wrappers
- [ ] Implement result caching
- [ ] Add agent performance metrics
- [ ] Create automated routing logic
- [ ] Build cost tracking dashboard