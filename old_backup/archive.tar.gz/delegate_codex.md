---
name: delegate-codex
description: Delegate a coding task to Codex CLI (uses subscription, not API)
---

You are Claude Code orchestrating multiple LLM agents. A user wants to delegate a coding task to Codex (via CLI).

## Coding Task to Delegate

$ARGUMENTS

## Your Orchestration Process

1. **Analyze the task** and determine if Codex is suitable:

   - Codex excels at: code generation, refactoring, bug fixes
   - Consider if this task is better handled by Codex or by you directly
   - Codex works best with clear, focused coding tasks
1. **Prepare the delegation**:

   - Identify target files (if any)
   - Determine context directory
   - Refine the task description for clarity
1. **Execute the delegation**:

   - Use the Codex wrapper script: `/home/claude/llm-orchestration/codex_wrapper.sh`
1. **Example bash commands**:

   ```bash
   # General coding task
   bash /home/claude/llm-orchestration/codex_wrapper.sh "Your refined task description"

   # Target specific file
   bash /home/claude/llm-orchestration/codex_wrapper.sh -f path/to/file.py "Fix the validation bug"

   # With context directory
   bash /home/claude/llm-orchestration/codex_wrapper.sh -c ./src "Refactor authentication module"

   # Save output for review
   bash /home/claude/llm-orchestration/codex_wrapper.sh -o codex_output.txt "Create API endpoint"
   ```
1. **Process the response**:

   - Review Codex's code output
   - Validate the solution
   - Test if necessary
   - Integrate into the project
   - If inadequate, refine the prompt and try again
1. **Integration workflow**:

   - Review the code Codex generated
   - Apply changes to actual files
   - Run tests
   - Commit if successful

## Token Efficiency Strategy

- Using Codex CLI costs nothing (subscription already paid)
- This saves your Claude API tokens
- Delegate routine coding tasks to Codex
- You handle complex architectural decisions and orchestration

## Decision Framework

Delegate to Codex when:

- Task is focused code generation or modification
- Clear requirements are specified
- Code structure is well-defined

Handle yourself when:

- Task requires understanding complex context
- Architectural decisions needed
- Multiple files need coordinated changes

Now execute the delegation and integrate the results appropriately.