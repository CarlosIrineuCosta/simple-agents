# System Architecture

## Visual Overview

```
┌──────────────────────────────────────────────────── ────┐
│                    👤 USER                             │
│                       │                                 │
│                       ↓                                 │
│              ┌────────────────┐                         │
│              │  Claude Code   │                         │
│              │  (Main Shell)  │                         │
│              └────────┬───────┘                         │
│                       │                                 │
│            Loads CLAUDE.md automatically                │
│            Makes /commands available                    │
│                       │                                 │
└───────────────────────┼─────────────────────────────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │  /orchestrate <task>          │
        │  (Custom Slash Command)       │
        └───────────────┬───────────────┘
                        │
                        ↓
        ┌───────────────────────────────┐
        │  Claude Analyzes & Routes     │
        │                               │
        │  Decision Logic:              │
        │  • Code task? → Codecs        │
        │  • Reasoning? → GLM           │
        │  • Chinese? → GLM             │
        │  • Complex context? → Self    │
        └───────────────┬───────────────┘
                        │
         ┌──────────────┼──────────────┐
         ↓              ↓              ↓
    ┌────────┐    ┌────────┐    ┌──────────┐
    │  Self  │    │  GLM   │    │  Codecs  │
    │(Claude)│    │  CLI   │    │   CLI    │
    └────────┘    └───┬────┘    └────┬─────┘
                      │              │
                      ↓              ↓
              ┌───────────────────────────┐
              │    Bash Tool (Claude)     │
              │                           │
              │  subprocess execution:    │
              │  • glm_wrapper.sh         │
              │  • codecs_wrapper.sh      │
              └───────────┬───────────────┘
                          │
                          ↓
              ┌───────────────────────────┐
              │   External CLI Process    │
              │                           │
              │   Returns stdout/stderr   │
              └───────────┬───────────────┘
                          │
                          ↓
              ┌───────────────────────────┐
              │  Claude Synthesizes       │
              │  • Validates output       │
              │  • Integrates results     │
              │  • Formats response       │
              └───────────┬───────────────┘
                          │
                          ↓
                    Final Answer
                          │
                          ↓
                      👤 USER
```

## Data Flow Examples

### Example 1: Simple GLM Delegation

```
User: "/orchestrate Explain quantum entanglement in Chinese"
  ↓
Claude: Analyzes → "Chinese content" → Route to GLM
  ↓
Bash Tool: Executes glm_wrapper.sh
  ↓
GLM CLI: Processes request (subscription, $0 cost)
  ↓
Returns: Chinese explanation
  ↓
Claude: Reviews, formats, returns to user
  ↓
User: Receives answer (Cost: ~$0.01 Claude orchestration only)
```

### Example 2: Multi-Agent Workflow

```
User: "/orchestrate Build Chinese news scraper with sentiment analysis"
  ↓
Claude: Complex task → Multi-agent workflow
  ↓
Step 1: GLM Analysis
  ├─ Bash: glm_wrapper.sh "Chinese sentiment analysis patterns"
  ├─ GLM: Returns analysis ($0)
  └─ Claude: Captures result
  ↓
Step 2: Codecs Implementation
  ├─ Bash: codecs_wrapper.sh "Build scraper using analysis: [GLM output]"
  ├─ Codecs: Returns code ($0)
  └─ Claude: Captures code
  ↓
Step 3: Claude Integration
  ├─ Reviews GLM analysis
  ├─ Reviews Codecs code
  ├─ Integrates components
  ├─ Adds error handling
  └─ Creates final deliverable
  ↓
User: Receives complete solution (Cost: ~$0.05 Claude orchestration)
```

## Cost Comparison

### Before (All Claude API):

```
Task: Generate 10 product descriptions
  ↓
Claude API: 10 × $0.015 = $0.15
  ↓
Total: $0.15
```

### After (With Orchestration):

```
Task: Generate 10 product descriptions
  ↓
Claude: Analyzes → Routes to GLM
  ↓
GLM CLI: Generates descriptions = $0 (subscription)
  ↓
Claude: Reviews = $0.01
  ↓
Total: $0.01 (93% savings)
```

## Component Interactions

### Wrapper Scripts

```
glm_wrapper.sh:
  ┌─ Input: User prompt
  ├─ Validate: Check CLI available
  ├─ Build: Construct command
  ├─ Execute: Run with timeout
  ├─ Capture: Get stdout/stderr
  └─ Return: Formatted output

codecs_wrapper.sh:
  ┌─ Input: Task description
  ├─ Validate: Check CLI available
  ├─ Parse: Extract file/context
  ├─ Build: Construct command
  ├─ Execute: Run with timeout
  ├─ Capture: Get code output
  └─ Return: Formatted code
```

### Custom Commands

```
/orchestrate:
  ┌─ Receives: User task
  ├─ Analyzes: Task requirements
  ├─ Decides: Best agent
  ├─ Routes: To chosen agent
  └─ Synthesizes: Final answer

/delegate-glm:
  ┌─ Receives: User task
  ├─ Refines: Prompt for GLM
  ├─ Executes: glm_wrapper.sh
  └─ Returns: GLM response

/delegate-codecs:
  ┌─ Receives: Coding task
  ├─ Prepares: Context/files
  ├─ Executes: codecs_wrapper.sh
  └─ Integrates: Generated code
```

## Session Flow

### Typical Session

```
1. User starts Claude Code:
   $ cd /home/claude/llm-orchestration
   $ claude

2. Claude loads CLAUDE.md (automatic)

3. User types command:
   > /orchestrate Create sorting algorithm

4. Claude's internal process:
   ┌─ Read command file
   ├─ Analyze task
   ├─ Choose agent (Codecs)
   ├─ Prepare bash command
   ├─ Execute via bash tool
   ├─ Receive output
   ├─ Validate result
   └─ Format response

5. User receives:
   - Generated code
   - Explanation
   - Integration steps
```

## System States

```
┌──────────────────────────────────────┐
│         READY STATE                  │
│                                      │
│  ✓ Wrappers executable               │
│  ✓ CLIs in PATH                      │
│  ✓ Commands loaded                   │
│  ✓ CLAUDE.md active                  │
└──────────────────────────────────────┘
            │
            ↓ User Command
            │
┌──────────────────────────────────────┐
│      ANALYZING STATE                 │
│                                      │
│  • Parse user input                  │
│  • Determine requirements            │
│  • Select optimal agent              │
└──────────────────────────────────────┘
            │
            ↓ Decision Made
            │
┌──────────────────────────────────────┐
│      EXECUTING STATE                 │
│                                      │
│  • Build command                     │
│  • Execute via bash                  │
│  • Monitor timeout                   │
│  • Capture output                    │
└──────────────────────────────────────┘
            │
            ↓ Results Received
            │
┌──────────────────────────────────────┐
│      SYNTHESIZING STATE              │
│                                      │
│  • Validate output                   │
│  • Combine results                   │
│  • Format response                   │
│  • Add context                       │
└──────────────────────────────────────┘
            │
            ↓ Complete
            │
┌──────────────────────────────────────┐
│      RESPONSE STATE                  │
│                                      │
│  • Deliver to user                   │
│  • Show next steps                   │
│  • Ready for next task               │
└──────────────────────────────────────┘
```

## Error Handling Flow

```
Error Occurs
    ↓
┌─────────────────────┐
│  Where did it fail? │
└──────┬──────────────┘
       │
   ┌───┴────┬────────┬─────────┐
   ↓        ↓        ↓         ↓
┌──────┐ ┌─────┐ ┌──────┐ ┌────────┐
│ CLI  │ │Bash │ │Parse │ │Timeout │
│Missing│ │Fail │ │Error │ │ Error  │
└──┬───┘ └──┬──┘ └───┬──┘ └────┬───┘
   │        │        │         │
   ↓        ↓        ↓         ↓
┌──────────────────────────────────┐
│      Fallback Strategy           │
│                                  │
│  • Log error                     │
│  • Try alternative agent         │
│  • Or handle with Claude         │
│  • Inform user clearly           │
└──────────────────────────────────┘
```

## Integration Points

### With Claude Code

```
Claude Code Native:
  • Bash tool (subprocess execution)
  • File system access
  • Custom commands (.claude/)
  • CLAUDE.md auto-loading
  • Session persistence

Our System:
  • Wrapper scripts (bash)
  • Custom commands (markdown)
  • Configuration (CLAUDE.md)
  • Intelligent routing (logic)
```

### With External CLIs

```
System → Wrapper → CLI

Wrapper provides:
  • Standardized interface
  • Error handling
  • Timeout management
  • Output formatting
  • Logging

CLI provides:
  • Core functionality
  • Model execution
  • Response generation
```

## Security Boundaries

```
┌─────────────────────────────────┐
│      User Space (You)           │
│  • Full system access           │
│  • Can run any command          │
└────────────┬────────────────────┘
             │
             ↓
┌─────────────────────────────────┐
│    Claude Code                  │
│  • Controlled bash access       │
│  • User-approved commands       │
│  • Project-scoped files         │
└────────────┬────────────────────┘
             │
             ↓
┌─────────────────────────────────┐
│    Wrapper Scripts              │
│  • Input validation             │
│  • Timeout limits               │
│  • Error boundaries             │
└────────────┬────────────────────┘
             │
             ↓
┌─────────────────────────────────┐
│    External CLIs                │
│  • Sandboxed execution          │
│  • Limited to CLI capabilities  │
│  • No system-level access       │
└─────────────────────────────────┘
```
