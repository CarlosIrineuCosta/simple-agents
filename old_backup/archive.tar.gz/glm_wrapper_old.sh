#!/bin/bash
# GLM CLI Wrapper for Claude Code Orchestration
# This script wraps the GLM CLI to make it easy for Claude Code to delegate tasks

set -e  # Exit on error

# Configuration
GLM_MODEL="${GLM_MODEL:-glm-4.5}"
GLM_THINKING="${GLM_THINKING:-enabled}"
TIMEOUT="${TIMEOUT:-120}"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Usage function
usage() {
    cat << EOF
Usage: $0 [OPTIONS] "<prompt>"

Options:
    -m, --model MODEL       GLM model to use (default: glm-4.5)
            Options: glm-4.5, glm-4.5-air
    -t, --thinking MODE     Thinking mode (default: enabled)
            Options: enabled, disabled
    -o, --output FILE       Save output to file
    -h, --help             Show this help message

Environment Variables:
    GLM_MODEL              Default model (default: glm-4.5)
    GLM_THINKING           Default thinking mode (default: enabled)
    TIMEOUT                Command timeout in seconds (default: 120)

Examples:
    # Basic usage
    $0 "Explain quantum computing"

    # With specific model
    $0 -m glm-4.5-air "Write a Python function for sorting"

    # Save output to file
    $0 -o result.txt "Analyze this data"

    # Disable thinking mode for faster response
    $0 -t disabled "Quick answer: what is 2+2?"
EOF
    exit 1
}

# Parse arguments
OUTPUT_FILE=""
while [[ $# -gt 0 ]]; do
    case $1 in
        -m|--model)
            GLM_MODEL="$2"
            shift 2
            ;;
        -t|--thinking)
            GLM_THINKING="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT_FILE="$2"
            shift 2
            ;;
        -h|--help)
            usage
            ;;
        *)
            PROMPT="$1"
            shift
            ;;
    esac
done

# Validate prompt
if [ -z "$PROMPT" ]; then
    echo -e "${RED}Error: No prompt provided${NC}" >&2
    usage
fi

# Log the request
echo -e "${BLUE}[GLM Wrapper] Sending to GLM-${GLM_MODEL} (thinking: ${GLM_THINKING})${NC}" >&2
echo -e "${BLUE}[GLM Wrapper] Prompt: ${PROMPT}${NC}" >&2

# Build GLM command based on actual CLI syntax
# Note: Adjust this based on actual GLM CLI syntax
# You'll need to verify the exact command format

# Check if GLM CLI is available
if ! command -v glm &> /dev/null && ! command -v glm-cli &> /dev/null; then
    echo -e "${RED}Error: GLM CLI not found in PATH${NC}" >&2
    echo -e "${RED}Please install GLM CLI or add it to your PATH${NC}" >&2
    exit 1
fi

# Determine which CLI command to use
GLM_CMD="glm"
if ! command -v glm &> /dev/null; then
    GLM_CMD="glm-cli"
fi

# Execute GLM with timeout
set +e  # Don't exit on error for timeout handling
if [ -n "$OUTPUT_FILE" ]; then
    # Save to file
    timeout "$TIMEOUT" $GLM_CMD --model "$GLM_MODEL" --thinking "$GLM_THINKING" "$PROMPT" > "$OUTPUT_FILE" 2>&1
    EXIT_CODE=$?
    if [ $EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}[GLM Wrapper] Success! Output saved to: $OUTPUT_FILE${NC}" >&2
        cat "$OUTPUT_FILE"
    fi
else
    # Output to stdout
    OUTPUT=$(timeout "$TIMEOUT" $GLM_CMD --model "$GLM_MODEL" --thinking "$GLM_THINKING" "$PROMPT" 2>&1)
    EXIT_CODE=$?
    if [ $EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}[GLM Wrapper] Success!${NC}" >&2
        echo "$OUTPUT"
    fi
fi

# Handle errors
if [ $EXIT_CODE -eq 124 ]; then
    echo -e "${RED}[GLM Wrapper] Error: Command timed out after ${TIMEOUT} seconds${NC}" >&2
    exit 124
elif [ $EXIT_CODE -ne 0 ]; then
    echo -e "${RED}[GLM Wrapper] Error: GLM CLI failed with exit code $EXIT_CODE${NC}" >&2
    exit $EXIT_CODE
fi

exit 0